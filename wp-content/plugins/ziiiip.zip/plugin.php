<?php
/**
 * Plugin Name: Nouhaila ELAALAMI 
 * Description: Mall plugin .
 */
add_filter('show_admin_bar','__return_false');